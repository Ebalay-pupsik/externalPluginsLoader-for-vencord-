﻿import { definePluginSettings } from "@api/Settings";
import SettingsPlugin from "@plugins/_core/settings";
import definePlugin, { OptionType, PluginNative } from "@utils/types";
import { React } from "@webpack/common";

const Native = VencordNative.pluginHelpers.ExternalPluginsLoader as PluginNative<typeof import("./native")>;

interface ExternalPluginItem {
    fileName: string;
    name: string;
    author: string;
    description: string;
    code: string;
    enabled: boolean;
    instance: { start?: () => void; stop?: () => void; } | null;
}

const DEFAULT_QUICK_TEMPLATE = `module.exports = {
    name: "QuickPlugin",
    author: "𝓈𝓌ℯℯ𝓉𝓎 𝓁𝒾𝓉𝓉𝓁ℯ 𝒷𝒶𝒷𝓎 (@myloveitskirill)",
    description: "Мой быстрый скрипт (редактируется прямо в Vencord)",

    start() {
        console.log("[QuickPlugin] Запущен!");
    },

    stop() {
        console.log("[QuickPlugin] Остановлен!");
    }
};`;

let pluginItems: ExternalPluginItem[] = [];
const listeners = new Set<() => void>();

function notifyUI() {
    listeners.forEach(fn => fn());
}

const settings = definePluginSettings({
    folderPath: {
        type: OptionType.STRING,
        description: "Свой путь к папке (пусто = AppData\\Roaming\\Vencord\\plugins)",
        default: "",
        restartNeeded: false
    },
    enabledMap: {
        type: OptionType.STRING,
        description: "Состояние включённых плагинов",
        default: "{}",
        hidden: true
    }
});

function getEnabledState(): Record<string, boolean> {
    try {
        return JSON.parse(settings.store.enabledMap || "{}");
    } catch {
        return {};
    }
}

function setPluginEnabledState(fileName: string, state: boolean) {
    const map = getEnabledState();
    map[fileName] = state;
    settings.store.enabledMap = JSON.stringify(map);
}

function parseMetadata(code: string, fallbackName: string) {
    const nameMatch = code.match(/name\s*:\s*["']([^"']+)["']/);
    const authorMatch = code.match(/author\s*:\s*["']([^"']+)["']/);
    const descMatch = code.match(/description\s*:\s*["']([^"']+)["']/);
    return {
        name: nameMatch ? nameMatch.at(1)! : fallbackName,
        author: authorMatch ? authorMatch.at(1)! : "Unknown Author",
        description: descMatch ? descMatch.at(1)! : "External Vencord JS Plugin."
    };
}

function stopSinglePlugin(item: ExternalPluginItem) {
    if (item.instance && typeof item.instance.stop === "function") {
        try {
            item.instance.stop();
        } catch (err) {
            console.error("[ExternalPluginsLoader] Ошибка остановки:", item.fileName, err);
        }
    }
    item.instance = null;
}

function startSinglePlugin(item: ExternalPluginItem) {
    stopSinglePlugin(item);
    try {
        const moduleObj: { exports: any; } = { exports: {} };
        const factory = new Function("module", "exports", "Vencord", item.code);
        factory(moduleObj, moduleObj.exports, (window as any).Vencord);

        const exported = moduleObj.exports?.default || moduleObj.exports;
        const instance = typeof exported === "function" ? exported() : exported;

        if (instance && typeof instance.start === "function") {
            instance.start();
        }
        item.instance = instance || {};
    } catch (err) {
        console.error("[ExternalPluginsLoader] Ошибка запуска:", item.fileName, err);
    }
}

async function syncPluginsFromDisk() {
    if (!Native?.readExternalPlugins) return;

    pluginItems.forEach(stopSinglePlugin);

    const res = await Native.readExternalPlugins(settings.store.folderPath);
    if (!res.ok) return;

    const savedState = getEnabledState();
    const nextItems: ExternalPluginItem[] = [];

    for (const file of res.files) {
        const meta = parseMetadata(file.code, file.name);
        const isEnabled = savedState[file.name] !== undefined ? savedState[file.name] : true;

        const item: ExternalPluginItem = {
            fileName: file.name,
            name: meta.name,
            author: meta.author,
            description: meta.description,
            code: file.code,
            enabled: isEnabled,
            instance: null
        };

        if (isEnabled) {
            startSinglePlugin(item);
        }

        nextItems.push(item);
    }

    pluginItems = nextItems;
    notifyUI();
}

function ExternalPluginsTab() {
    const [, forceUpdate] = React.useReducer((x: number) => x + 1, 0);
    const [editorOpen, setEditorOpen] = React.useState(false);
    const [quickCode, setQuickCode] = React.useState(DEFAULT_QUICK_TEMPLATE);
    const [statusMsg, setStatusMsg] = React.useState("");

    React.useEffect(() => {
        listeners.add(forceUpdate);
        return () => {
            listeners.delete(forceUpdate);
        };
    }, []);

    const openQuickEditor = () => {
        if (!editorOpen) {
            const existing = pluginItems.find(p => p.fileName === "QuickPlugin.js");
            if (existing) {
                setQuickCode(existing.code);
            }
            setStatusMsg("");
        }
        setEditorOpen(!editorOpen);
    };

    const handleSaveAndRun = async () => {
        if (!Native?.saveQuickPlugin) return;
        const res = await Native.saveQuickPlugin(quickCode, settings.store.folderPath);
        if (res.ok) {
            setPluginEnabledState("QuickPlugin.js", true);
            await syncPluginsFromDisk();
            setStatusMsg("Сохранено и запущено!");
            setTimeout(() => setStatusMsg(""), 2500);
        } else {
            setStatusMsg("Ошибка: " + (res.error || "неизвестно"));
        }
    };

    const toggleItem = (item: ExternalPluginItem) => {
        item.enabled = !item.enabled;
        setPluginEnabledState(item.fileName, item.enabled);
        if (item.enabled) {
            startSinglePlugin(item);
        } else {
            stopSinglePlugin(item);
        }
        forceUpdate();
    };

    const h = React.createElement;

    const cards = pluginItems.map(item =>
        h("div", {
            key: item.fileName,
            style: {
                background: "var(--background-secondary, #2b2d31)",
                borderRadius: "8px",
                padding: "14px 16px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "12px"
            }
        },
            h("div", { style: { minWidth: 0 } },
                h("div", { style: { fontWeight: 700, fontSize: "14px", color: "#fff" } }, item.name),
                h("div", { style: { fontSize: "12px", color: "#949ba4", marginTop: "2px" } }, "by " + item.author),
                h("div", { style: { fontSize: "12px", color: "#dbdee1", marginTop: "6px" } }, item.description)
            ),
            h("div", {
                onClick: () => toggleItem(item),
                style: {
                    width: "40px",
                    height: "24px",
                    borderRadius: "99px",
                    background: item.enabled ? "#5865F2" : "#4e5058",
                    position: "relative",
                    cursor: "pointer",
                    flexShrink: 0
                }
            },
                h("div", {
                    style: {
                        width: "18px",
                        height: "18px",
                        borderRadius: "50%",
                        background: "#fff",
                        position: "absolute",
                        top: "3px",
                        left: item.enabled ? "19px" : "3px"
                    }
                })
            )
        )
    );

    const editorPanel = editorOpen
        ? h("div", {
            style: {
                background: "#1e1f22",
                border: "1px solid #3f4147",
                borderRadius: "8px",
                padding: "14px",
                marginBottom: "20px",
                display: "flex",
                flexDirection: "column",
                gap: "10px"
            }
        },
            h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center" } },
                h("span", { style: { fontWeight: 700, fontSize: "14px", color: "#fff" } }, "QuickPlugin.js Editor"),
                statusMsg ? h("span", { style: { fontSize: "12px", color: "#23a559", fontWeight: 600 } }, statusMsg) : null
            ),
            h("textarea", {
                value: quickCode,
                onChange: (e: any) => setQuickCode(e.target.value),
                spellCheck: false,
                style: {
                    width: "100%",
                    height: "220px",
                    background: "#111214",
                    color: "#dbdee1",
                    border: "1px solid #3f4147",
                    borderRadius: "6px",
                    padding: "10px",
                    fontFamily: "Consolas, monospace",
                    fontSize: "12px",
                    resize: "vertical",
                    boxSizing: "border-box"
                }
            }),
            h("div", { style: { display: "flex", gap: "10px" } },
                h("button", {
                    type: "button",
                    onClick: handleSaveAndRun,
                    style: {
                        cursor: "pointer",
                        background: "#248046",
                        border: "none",
                        borderRadius: "6px",
                        padding: "8px 16px",
                        color: "#fff",
                        fontWeight: 600,
                        fontSize: "13px"
                    }
                }, "Save & Run QuickPlugin"),
                h("button", {
                    type: "button",
                    onClick: () => setQuickCode(DEFAULT_QUICK_TEMPLATE),
                    style: {
                        cursor: "pointer",
                        background: "#4e5058",
                        border: "none",
                        borderRadius: "6px",
                        padding: "8px 14px",
                        color: "#fff",
                        fontWeight: 600,
                        fontSize: "13px"
                    }
                }, "Сбросить шаблон")
            )
        )
        : null;
    return h("div", { style: { padding: "16px 8px", color: "#f2f3f5" } },
        h("div", {
            style: {
                background: "rgba(240, 178, 50, 0.08)",
                border: "1px solid rgba(240, 178, 50, 0.45)",
                borderRadius: "8px",
                padding: "14px 16px",
                marginBottom: "18px"
            }
        },
            h("div", { style: { fontWeight: 700, fontSize: "15px", marginBottom: "6px", color: "#fff" } }, "External Plugins"),
            h("div", { style: { fontSize: "13px", color: "#dbdee1" } }, "Помещай любые .js плагины в папку AppData\Roaming\Vencord\plugins или пиши код прямо в QuickPlugin.")
        ),
        h("div", { style: { display: "flex", flexWrap: "wrap", gap: "10px", marginBottom: "20px" } },
            h("button", {
                type: "button",
                onClick: () => Native?.openPluginsFolder(settings.store.folderPath),
                style: {
                    cursor: "pointer",
                    background: "#2b2d31",
                    border: "1px solid #3f4147",
                    borderRadius: "8px",
                    padding: "12px 14px",
                    color: "#fff",
                    fontWeight: 600,
                    fontSize: "13px"
                }
            }, "Open Plugins Folder"),
            h("button", {
                type: "button",
                onClick: () => syncPluginsFromDisk(),
                style: {
                    cursor: "pointer",
                    background: "#2b2d31",
                    border: "1px solid #3f4147",
                    borderRadius: "8px",
                    padding: "12px 14px",
                    color: "#fff",
                    fontWeight: 600,
                    fontSize: "13px"
                }
            }, "Load missing Plugins"),
            h("button", {
                type: "button",
                onClick: openQuickEditor,
                style: {
                    cursor: "pointer",
                    background: editorOpen ? "#5865F2" : "#2b2d31",
                    border: "1px solid #3f4147",
                    borderRadius: "8px",
                    padding: "12px 14px",
                    color: "#fff",
                    fontWeight: 600,
                    fontSize: "13px"
                }
            }, "Edit QuickPlugin")
        ),
        editorPanel,
        pluginItems.length === 0
            ? h("div", { style: { color: "#949ba4", fontSize: "13px", padding: "12px", background: "#2b2d31", borderRadius: "8px" } }, "В папке plugins пока нет .js файлов.")
            : h("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: "12px" } }, cards)
    );
}
export default definePlugin({
    name: "ExternalPluginsLoader",
    description: "Добавляет вкладку External Plugins и редактор QuickPlugin (как QuickCSS) для загрузки .js модов",
    authors: [{ name: "𝓈𝓌ℯℯ𝓉𝓎 𝓁𝒾𝓉𝓉𝓁ℯ 𝒷𝒶𝒷𝓎 (@myloveitskirill)", id: 1399448306194714786n }],
    settings,
    start() {
        const customSections = (SettingsPlugin as any).customSections;
        if (Array.isArray(customSections)) {
            customSections.push(() => ({
                section: "VencordExternalPlugins",
                label: "External Plugins",
                element: ExternalPluginsTab
            }));
        }
        syncPluginsFromDisk();
    },
    stop() {
        const customSections = (SettingsPlugin as any).customSections;
        if (Array.isArray(customSections)) {
            const idx = customSections.findIndex((fn: any) => fn()?.section === "VencordExternalPlugins");
            if (idx !== -1) customSections.splice(idx, 1);
        }
        pluginItems.forEach(stopSinglePlugin);
        pluginItems = [];
    }
});