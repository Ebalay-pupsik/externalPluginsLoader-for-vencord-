import { IpcMainInvokeEvent, shell } from "electron";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";

export function getDefaultPluginsDir(_?: IpcMainInvokeEvent): string {
    const appData = process.env.APPDATA || path.join(os.homedir(), "AppData", "Roaming");
    return path.join(appData, "Vencord", "plugins");
}

export function openPluginsFolder(_: IpcMainInvokeEvent, customDir?: string): string {
    const targetDir = customDir?.trim() || getDefaultPluginsDir();
    if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, { recursive: true });
    }
    shell.openPath(targetDir);
    return targetDir;
}

export function saveQuickPlugin(_: IpcMainInvokeEvent, code: string, customDir?: string): { ok: boolean; error?: string; } {
    const targetDir = customDir?.trim() || getDefaultPluginsDir();
    try {
        if (!fs.existsSync(targetDir)) {
            fs.mkdirSync(targetDir, { recursive: true });
        }
        fs.writeFileSync(path.join(targetDir, "QuickPlugin.js"), code, "utf8");
        return { ok: true };
    } catch (err: any) {
        return { ok: false, error: String(err?.message || err) };
    }
}

export function readExternalPlugins(_: IpcMainInvokeEvent, customDir?: string): { ok: boolean; dir: string; error?: string; files: { name: string; code: string; }[]; } {
    const targetDir = customDir?.trim() || getDefaultPluginsDir();
    try {
        if (!fs.existsSync(targetDir)) {
            fs.mkdirSync(targetDir, { recursive: true });
        }

        const entries = fs.readdirSync(targetDir).filter(f => f.endsWith(".js"));
        const files = entries.map(name => ({
            name,
            code: fs.readFileSync(path.join(targetDir, name), "utf8")
        }));

        return { ok: true, dir: targetDir, files };
    } catch (err: any) {
        return { ok: false, dir: targetDir, error: String(err?.message || err), files: [] };
    }
}
